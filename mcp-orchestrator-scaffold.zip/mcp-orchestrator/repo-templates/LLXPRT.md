
# LLXPRT.md — Qwen + Gemini

## Uso rápido
- `./scripts/qwen-run.sh playbooks/<feature>.md`

## Notas
- Exporta `QWEN_MODEL` si deseas otro modelo.
- Requiere binario `llxprt` accesible en PATH.
