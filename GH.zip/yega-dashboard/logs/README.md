# Logs de la aplicación Yega Dashboard
# Este directorio contiene todos los archivos de log

# Logs disponibles:
# - sync.log: Sincronización con GitHub
# - github.log: Requests a GitHub API
# - database.log: Operaciones de base de datos
# - cron.log: Ejecuciones programadas

# Configuración recomendada para rotación de logs
# Agregar a /etc/logrotate.d/yega-dashboard:

/ruta/a/yega-dashboard/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    copytruncate
}